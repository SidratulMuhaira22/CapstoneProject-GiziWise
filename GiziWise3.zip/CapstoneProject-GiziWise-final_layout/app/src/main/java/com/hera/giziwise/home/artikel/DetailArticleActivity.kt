package com.hera.giziwise.home.artikel

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.hera.giziwise.R

class DetailArticleActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail_article)
    }
}