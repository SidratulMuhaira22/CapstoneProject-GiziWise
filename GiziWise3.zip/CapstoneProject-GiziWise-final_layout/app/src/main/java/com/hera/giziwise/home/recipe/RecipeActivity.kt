package com.hera.giziwise.home.recipe

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.hera.giziwise.R

class RecipeActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_recipe)
    }
}