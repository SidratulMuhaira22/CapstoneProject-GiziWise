package com.hera.giziwise.home.recipe

import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import com.hera.giziwise.R

class BahanResepActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail_resep_bahan)
    }
    fun button(view: View) {

    }
}
